#include <bits/stdc++.h>
using namespace std;

class Test
{
    string s;
public:
    void generateTest();
    friend istream& operator>>(istream& in, Test &test);
    friend ostream& operator<<(ostream& out, Test &test);
};

void Test::generateTest()
{
    s.clear();
    unsigned long long a;
    string s_add;
    int n=rand()%1000;
    stringstream ss;
    a=rand();
    a*=rand();
    a*=rand();
    a*=rand();
    a%=9223372036854775807;
    ss<<a<<' ';
    ss>>s;
    for(int i=1; i<n; ++i)
    {
        if(rand()%2) s+='+';
        else s+='-';
        a=abs(rand()*rand()*rand()*rand());
        ss<<a<<' ';
        ss>>s_add;
        s+=s_add;
    }
}

istream& operator>>(istream& in, Test &test)
{
    in>>test.s;
    return in;
}

ostream& operator<<(ostream& out, Test &test)
{
    out<<test.s;
    return out;
}

class Answer
{
    string s;
public:
    bool operator!=(Answer& answer)
    {
        return s!=answer.s;
    }

    friend istream& operator>>(istream& , Answer &);
    friend ostream& operator<<(ostream& , Answer &);
};

istream& operator>>(istream& in, Answer &answer)
{
    in>>answer.s;
    return in;
}

ostream& operator<<(ostream& out, Answer &answer)
{
    out<<answer.s;
    return out;
}

int main()
{
    srand(time(0));
    Test test;



    string name1="E:\\projects_code_blocks\\contests\\strings1\\expression1", name_correct="E:\\projects_code_blocks\\contests\\strings1\\Myroslave";
    int n_tests=10000;



    const char start1[]="\" < tests.txt > answers1.txt",
               start_correct[]="\" < tests.txt > answers2.txt";
    Answer answer1,correct_answer;
    ofstream ofile, oprotocol("protocol.txt");
    ifstream ifile1,ifile2;
    bool flag=1;
    for(int i=1;i<=n_tests;++i)
    {
        int time=clock();
        cout<<"Test "<<i<<": ";
        oprotocol<<"Test "<<i<<": ";
        test.generateTest();
        ofile.open("tests.txt");
        ofile<<test;
        ofile.close();
        int time1=clock();
        system(('"'+name1+".exe"+start1).c_str());
        cout<<"1\n";
        time1=clock()-time1;
        int time2=clock();
        system(('"'+name_correct+".exe"+start_correct).c_str());
        cout<<"2\n";
        time2=clock()-time2;
        ifile1.open("answers1.txt");
        ifile1>>answer1;
        ifile1.close();
        ifile2.open("answers2.txt");
        ifile2>>correct_answer;
        ifile2.close();
        if(answer1!=correct_answer)
        {
            cout<<"WA";
            oprotocol<<"WA\n";
            cout<<'\n'<<test<<'\n';
            system("color 04");
            cout<<"Correct answer is : "<<correct_answer<<'\n';
            cout<<"Your answer is : "<<answer1<<'\n';
            //system("del answers1.txt");
            //system("del answers2.txt");
            //system("del tests.txt");
            system("pause");
            flag=0;
        }
        else {cout<<"ok"; oprotocol<<"ok\n";}
        cout<<'\n';
        time=clock()-time;
        cout<<time1<<' '<<time2<<' '<<time<<'\n';
        oprotocol<<test<<'\n';
        oprotocol<<time1<<' '<<time2<<' '<<time<<'\n';
        oprotocol.flush();
    }
    if(flag) system("color 02");
    //system("del answers1.txt");
    //system("del answers2.txt");
    //system("del tests.txt");
    oprotocol.close();
    return 0;
}

